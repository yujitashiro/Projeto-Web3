package org.hibernate.validator.referenceguide.chapter11.constraintapi;

import java.util.Date;

public interface Tournament {
	Date getTournamentDate();
}


